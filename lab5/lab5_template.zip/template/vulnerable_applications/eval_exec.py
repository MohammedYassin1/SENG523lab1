def my_eval(expr):
    return eval(expr)

def my_exec(code):
    exec(code)

def my_literal():
    return eval("1 + 2")
